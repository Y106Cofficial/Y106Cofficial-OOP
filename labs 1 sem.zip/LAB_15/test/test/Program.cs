﻿using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;

namespace Lab_15
{
    class Test
    {
        static BlockingCollection<string> coll;
        static void producer()
        {
            string[] goods = new string[] { "wood", "metal", "tea", "computer", "headset" };
            foreach (string item in goods)
            {
                coll.Add(item);
                Console.WriteLine("The warehouse has been added with: " + item);
            }
        }

        static void customer()
        {
            string item;
            while (!coll.IsCompleted)
            {
                if (coll.TryTake(out item))
                {
                    Console.WriteLine("Customer bought: " + item);
                }
            }
        }

        static void Main()
        {
            coll = new BlockingCollection<string>();
            Task produc = new Task(producer);
            Task cust = new Task(customer);
            produc.Start();
            cust.Start();
            try
            {
                produc.Wait();
                cust.Wait();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            finally
            {
                cust.Dispose();
                produc.Dispose();
                coll.Dispose();
            }
            Console.ReadLine();
        }
    }
}