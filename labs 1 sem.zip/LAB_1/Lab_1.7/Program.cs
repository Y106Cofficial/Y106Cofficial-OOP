﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_1._7
{
    internal class Program
    {
        
        static void Retorl(int[] numbers, string str)
        {
            (int MinA, int MaxA, int Sum, char FirstL) tuple;
            tuple.MinA = numbers.Min();
            tuple.MaxA = numbers.Max();
            int summa = 0;
            foreach (int item in numbers)
            {
                summa += item;
            }
            tuple.Sum = summa;
            tuple.FirstL = str[0];
            Console.WriteLine($"Максимальый элемент = {tuple.MaxA}, Минимальный элемент = {tuple.MinA}, Сумма = {tuple.Sum}, Первая буква = {tuple.FirstL}");
        }
        static int CheckedFun()
        {
            int val1 = checked(2147483647);
            return val1;
        }
        static int UnCheckedFun()
        {
            int val2 = unchecked(2147483647+1);
            return val2;
        }
         static void Main(string[] args)
        {
            Console.WriteLine("ФУНКЦИИ");
            int[] MyArr = new int[4] { 1, 2, 3, 4 };
            string myStr = "Yura";
            Retorl(MyArr, myStr);
            Console.WriteLine("CHECKED AND UNCHECKED");
            Console.Write($"Checked = { CheckedFun()}, Uncheked = {UnCheckedFun()}\n");

        }
    }
}
