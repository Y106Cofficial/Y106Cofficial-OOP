﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1_1._3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] myArray = { 5,7,2,5,7,8,10 };
            var massive = myArray;
            for (int i = 0; i < myArray.Length; i++)
            {
                Console.WriteLine(myArray[i]);
            }
            Console.WriteLine(massive);

            var stroka = "What you mean in this task";
            Console.WriteLine(stroka + " " + stroka.Length);

            

        }

           
    }
}
