﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_1._2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[][] myArray = new double[3][];
            myArray[0] = new double[2];
            myArray[1] = new double[3];
            myArray[2] = new double[4];
            

            for (int i = 0; i < myArray.Length; i++)
            {
                for (int j = 0; j < myArray[i].Length; j++)
                {
                    Console.WriteLine("Введите элемент I: " + i + "  " + "J: " + j); 
                    myArray[i][j] = double.Parse(Console.ReadLine());   
                }
            }
            Console.WriteLine("Полученный массив:\n");

            for (int i = 0; i < myArray.Length; i++)
            {
                for (int j = 0; j < myArray[i].Length; j++)
                {
                    Console.Write(myArray[i][j] + "\t");
                }
                Console.WriteLine();
            }
        }
    }
}
        
    

