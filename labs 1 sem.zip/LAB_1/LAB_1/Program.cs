﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;


namespace LAB_1
{
    internal class Program
    {

        static void Main(string[] args)
        {

            Console.WriteLine("Введите число от 0 до 254");//примитив типа байт
            byte a = Convert.ToByte(Console.ReadLine());
            Console.WriteLine(a);

            Console.WriteLine("Введите число от -128 до 126");//примитив типа сбайт
            sbyte b = Convert.ToSByte(Console.ReadLine());
            Console.WriteLine(b);

            Console.WriteLine("Введите число от -32768 до 32767");//примитив типа short
            short c = Convert.ToInt16(Console.ReadLine());
            Console.WriteLine(c);

            Console.WriteLine("Введите число от 0 до 65535");//примтитив типа ushort
            ushort d = Convert.ToUInt16(Console.ReadLine());
            Console.WriteLine(d);   

            Console.WriteLine("Введите число типа int");// примиитив типа Int
            int i = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(i);

            Console.WriteLine("Введите число типа uint");// примитив типа UInt
            uint j = Convert.ToUInt32(Console.ReadLine());
            Console.WriteLine(j);

            Console.WriteLine("Введите число типа long");//примитив типа long
            long l = Convert.ToInt64(Console.ReadLine());
            Console.WriteLine(l);

            Console.WriteLine("Введите число типа ulong");//примитив типа ulong
            ulong r = Convert.ToUInt64(Console.ReadLine());
            System.Console.WriteLine(r);

            /*числовые с плавающей точкой*/

            Console.WriteLine("Введите число типа float");//примтив типа float
            float f = Convert.ToSingle(Console.ReadLine());
            Console.WriteLine(f);

            Console.WriteLine("Введите число типа double");//примтив типа double
            double g = double.Parse(Console.ReadLine());
            Console.WriteLine(g);

            Console.WriteLine("Введите число типа deciml");//примтив типа decimal
            decimal y = decimal.Parse(Console.ReadLine());
            Console.WriteLine(y);

            /*Символьные типы*/

            char ch;                                // тип char
            Console.WriteLine("Введите символ");
            int symbol = Console.Read();
            ch = Convert.ToChar(symbol);
            Console.WriteLine(ch);


            Console.WriteLine("введите любое слово или предложение ");//Тип string
            string x = Console.ReadLine();
            Console.WriteLine(x);

            //Логический тип bool, значения или True или False
            Console.WriteLine("Введите T or f");
            string m = Console.ReadLine();
            if (m == "T")
            {
                Console.WriteLine("True");
            }
            else
            {
                Console.WriteLine("False");
            }

            //неявное приведение 
            int num = 21442345;
            long num1 = num;
            Console.WriteLine(num1);

            byte num2 = 126;
            int num3 = num2;
            Console.WriteLine(num3);

            sbyte num4 = -126;
            int num5 = num4;
            Console.WriteLine(num5);

            ushort num6 = 6553;
            int num7 = num6;
            Console.WriteLine(num7);

            short num8 = -6553;
            int num9 = num8;
            Console.WriteLine(num9);

            //явное приведение
            double pr = 1234.7;
            int pr1;
            pr1 = (int)pr;
            Console.WriteLine(pr1);

            double pr2 = -1234.7;
            int pr3;
            pr3 = (int)pr2;
            Console.WriteLine(pr3);

            double pr4 = 2.76;
            float pr5;
            pr5 = (int)pr4;
            Console.WriteLine(pr5);

            decimal pr6 = -374378;
            double pr7;
            pr7 = (double)pr6;
            Console.WriteLine(pr7);

            double pr8 = 110.3;
            short pr9;
            pr9 = (short)pr8;
            Console.WriteLine(pr9);


            //упаковка(перемещение значения значимого типа в ссылочный, то есть перемещение его из стэка в кучу)
            int pack = 123;
            object pack1 = pack;
            Console.WriteLine(pack1);
            int unpack = (int) pack1;//Роспаковка типоов(присвоение значение значимой переменной из кучи в стэк)
            Console.WriteLine(unpack);

            var neyavno = 5;
            int result = neyavno + 5;
            Console.WriteLine(result);

            //neyavno = "Hell";// Тк система опредеолила переменной neyavno тип инт, то мы не можем посметить в неёё какие либо данный кроме типа данных инт

            int? wer = null;
            Console.WriteLine(wer == null ? "Empty" : "Not empty");




        }
    }
}
