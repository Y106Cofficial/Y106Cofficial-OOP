﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_1._4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*string stroka1 = "Ola niigas";
            string stroka2 = "Hello niggas";
            if (stroka1 == stroka2)
            {
                Console.WriteLine("Строка один не равна строке 2");      
            }
            else
            {
                Console.WriteLine("Строка один равна строке 2");
            }*/

            string S1 = "First", S2 = "Second", S3 = "Third", S4 = "";
            S4 = S1 + " " + S2 + " ";
            S4 = string.Concat(S4,"CoCo");
            Console.WriteLine($"Сцепление(конкатенация) строк = {S4}");
            S4 = "";
            S4 = string.Copy(S1);
            Console.WriteLine($"Копирование строк = {S4}");
            S4 = "My House";
            S4 = S4.Substring(0,2);
            Console.WriteLine($"Результат = {S4}");
            S4 = "I love my University";
            string[] StringArray = S4.Split(' ');
            foreach (var item in StringArray)
            {
               Console.WriteLine($"Вот 1 слово из предложения = {item}");
            }
            S4 = "House";
            S4 = S4.Insert(2,S1);
            Console.WriteLine($"Вставка подстроки в строку = {S4}");
            S4 = "Play together";
            int ind = S4.Length - 8;
            S4 = S4.Remove(ind);
            Console.WriteLine($"Удаление подстроки = {S4}");
            S4 = "Garee";
            int number = 24;
            string S5 = String.Format($"Street name = {S4}, Number = {number}");
            Console.WriteLine($"Интерполяция = {S5}");


        }
    }
}
