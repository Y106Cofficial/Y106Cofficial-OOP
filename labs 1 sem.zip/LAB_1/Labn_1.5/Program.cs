﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labn_1._5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] SArray = { "House", "School", "Work" };
            foreach (var item in SArray)
            {
            Console.Write($"{item} ");
            }
            Console.WriteLine();
            int Length = SArray.Length;
            string NewWord;
            Console.WriteLine($"Введите элемент который поменять местами: ");
            int OldWord = Convert.ToInt32(Console.ReadLine());
            NewWord = Console.ReadLine();
            SArray[OldWord] = NewWord;
            foreach (var item in SArray)
            {
            Console.Write($"{item} ");
            }
            Console.WriteLine();
        }
    }
}
