﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_1._6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            (int, string, char, string, ulong) tuple = (25, "Yura", 'X', "Car", 256);
            (int,string,char,string,ulong) tupleB = (2556,"YuraKDHD",'O',"CarPPPP",2);
            Console.WriteLine("Вывод весь кортеж:");
            Console.Write($"{tuple.Item1}\t{tuple.Item2}\t{tuple.Item3}\t{tuple.Item4}\t{tuple.Item5}\n");
            Console.WriteLine($"{tuple.Item4}");
            var first = tuple.Item1;
            var second = tuple.Item2;
            var third = tuple.Item3;
            var fourth = tuple.Item4;
            var fifth = tuple.Item5;
            if (tuple == tupleB)
            {
            Console.WriteLine("Кортежи совпадают");
            }
            else
            {
            Console.WriteLine("Кортежи не совпадают");
            }
        }
    }
}
