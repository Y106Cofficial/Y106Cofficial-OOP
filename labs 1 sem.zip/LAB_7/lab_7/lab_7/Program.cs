﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace lab_7
{
    public interface IMyInterface<T>   //Обобщенный интерфейс с операциями добавления, удаления, просмотра
    {                           // Но интерфейс только содержит эти методы далее эти методы будут реализованы
        void Add(T obj);
        void Delete(T obj);
        void Show();
    }
    public class Human  // производный класс 
    {
        public string name;

        public int age;

        public Human()
        {

        }
    }
    public class CollectionType<T> : IMyInterface<T> where T : Human    // Создание обобщенного класса с ограничением
    {                                                                   // Ограничение подразумевает то, что под T должен быть класс Human
        public List<T> my_collection = new List<T>();                   //Поясню, обобщеный тип говорит о том, что мы еще не знаем какой тип данных мы будет использовать, но ограничение говорит о том что, наш тип будет типо ограничения :)
                                                                        // my_collection это обобщенная коллекция 
        public void Add(T obj)  // Реализация метода Добавления
        {
            my_collection.Add(obj);
        }

        public void Delete(T obj)   // Реализация метода Удаления
        {
            my_collection.Remove(obj);
        }

        public void Show()  // Реализация метода Просмотра
        {
            foreach (Human item in my_collection)
            {
                Console.WriteLine($"Name:{item.name}, Age:{item.age}");
            }
        }

        public void Save_To_File(string path)   // Метод сохранения данных в файл, в переменную path закинь свой путь до файла 
        {
            using (StreamWriter writer = new StreamWriter(path, true))
            {
                foreach (Human item in my_collection)
                {
                    writer.WriteLine($"Name:{item.name}, Age:{item.age}");
                }
                writer.Close();
            }
        }

    }
    internal class Program
    {
        static void Main(string[] args)
        {
            try // Обработка исключений с блоком finally
            {
                Human Ivan = new Human();
                Ivan.age = 32;
                Ivan.name = "Ivan";
                Human Nikita = new Human();
                Nikita.age = 27;
                Nikita.name = "Nikita";
                Human Denis = new Human();
                Denis.age = 20;
                Denis.name = "Denis";
                Human Igor = new Human();
                Igor.age = 19;
                Igor.name = "Igor";
                Human Peter = new Human();
                Peter.age = 45;
                Peter.name = "Peter";

                CollectionType<Human> MyCollection = new CollectionType<Human>();
                MyCollection.Add(Ivan);
                MyCollection.Add(Nikita);
                MyCollection.Add(Denis);
                MyCollection.Add(Igor);
                MyCollection.Add(Peter);
                MyCollection.Show();
                MyCollection.Delete(Denis);
                Console.WriteLine("---");
                MyCollection.Show();
                MyCollection.Save_To_File(@"E:\3 семестр лабы\ООП\LAB_7\lab_7\Example.txt");

            }
            catch (Exception)
            {
                throw new Exception("При выполнении программы была совершенна ошибка!");
            }
            finally
            {
                Console.WriteLine("Программа была выполнена без ошибок!");
            };

        }  
    }
}

