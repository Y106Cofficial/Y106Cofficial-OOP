﻿using ThreeConstructors;
using Shoto;
using System.Collections.Generic;
using System.Linq;
using System;

namespace Task
{
    public class First_Task_Main
    {
        static void Main()
        {
            string[] Month = {//months 1st task
                "January",
                "February",
                "March",
                "April",
                "May",
                "June",
                "July",
                "August",
                "September",
                "October",
                "November",
                "December"
                };

            var Selected_Month =
            from p in Month
            where p.Length == 4
            select p;//результирующий набор типа элемент

            Console.WriteLine("Запрос выбирающий последовательность месяцев с длиной строки равной n:");

            foreach (string month in Selected_Month)
            {
                Console.WriteLine(month);
            }
            Console.WriteLine("---");

            Selected_Month =
            from p in Month
            where p.StartsWith("D") || p.StartsWith("J") || p.StartsWith("F") || p.StartsWith("J") || p.StartsWith("Au")
            select p;

            Console.WriteLine("Запрос возвращающий только летние и зимние месяцы");

            foreach (string month in Selected_Month)
            {
                Console.WriteLine(month);
            }
            Console.WriteLine("---");

            Selected_Month =
            from p in Month
            orderby p//сортировка по алфавиту 
            select p;

            Console.WriteLine("Запрос вывода месяцев в алфавитном порядке:");

            foreach (string month in Selected_Month)
            {
                Console.WriteLine(month);
            }
            Console.WriteLine("---");

            Selected_Month =
            from p in Month
            where p.Contains('u') && p.Length >= 4
            select p;

            Console.WriteLine("Запрос считающий месяцы содержащие букву «u» и длиной имени не менее 4-х:");

            foreach (string month in Selected_Month)
            {
                Console.WriteLine(month);
            }
            Console.WriteLine("---");

            List<Student> My_List = new List<Student>();//лист студентов

            Student student_1 = new Student("Bondarenko", 18, 3, 2, 3, 1);
            Student student_2 = new Student ("Kirienko", 19, 3, 9, 8, 3);
            Student student_3 = new Student("Pashkevich", 18, 3, 2, 2, 4);
            Student student_4 = new Student("Miloshko", 18, 3, 4, 5, 6);
            Student student_5 = new Student("KimChen", 19, 3, 7, 8, 8);
            Student student_6 = new Student("Kingsman", 20, 4, 6, 7, 8);
            Student student_7 = new Student("Petrov", 17, 1, 5, 5, 10);
            Student student_8 = new Student("Ignarev", 17, 1, 8, 9, 4);
            Student student_9 = new Student("Pashkovich", 20, 3, 5, 5, 5);
            Student student_10 = new Student("Nikitonchikov", 18, 3, 6, 8, 8);

            My_List.Add(student_1);
            My_List.Add(student_2);
            My_List.Add(student_3);
            My_List.Add(student_4);
            My_List.Add(student_5);
            My_List.Add(student_6);
            My_List.Add(student_7);
            My_List.Add(student_8);
            My_List.Add(student_9);
            My_List.Add(student_10);
            //Вот оно
            Console.WriteLine("----------");
            var Select_people =
            from example in My_List
            where example.ocenki[0] < 4 || example.ocenki[1] < 4 || example.ocenki[2] < 4
            select example;
            Console.WriteLine("Ученики имеющие отрицательные оценки: ");
            foreach (var item in Select_people)
            {
                Console.WriteLine(item.FIO);
            }
            var Spisok =
            from example in My_List
            where example.ocenki[0] + example.ocenki[1] + example.ocenki[2] > 15
            select example;
            Console.WriteLine("Ученики имеющие оценки у которых сумма балов больше 15: ");
            foreach (var item in Spisok)
            {
                Console.WriteLine(item.FIO);
            }
            var Only_10 =
            from example in My_List
            where example.ocenki[2] == 10
            select example;
            Console.WriteLine("Ученики имеющие 10 по третьему предмету: ");
            foreach (var item in Only_10)
            {
                Console.WriteLine(item.FIO);
            }
            var Array_People =
            from example in My_List
            orderby example.FIO
            select example;
            Console.WriteLine("Массив абитуриентов: ");
            foreach (var item in Array_People)
            {
                Console.WriteLine(item.FIO);
            }
            var Poslednie_4 =
            from example in My_List
            orderby example.Perfomance()
            select example;
            Console.WriteLine("Последние");
            foreach (var item in Poslednie_4)
            {
                Console.WriteLine(item.FIO + " И общая " + item.Perfomance());
            }
            Console.WriteLine("А ВОТ И ОНИ!!!!");
            int count = 0;
            foreach (var item in Poslednie_4)
            {
                if (count == 4)
                {
                    break;
                }
                Console.WriteLine(item.FIO + " И общая " + item.Perfomance());
                count++;
            }
            Console.WriteLine("--------------");
            // А все 4 задание
            int[] My_Array1 = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 20, 50, 100 };    //290
            int[] My_Array2 = new int[] { 10, 20, 3, 40, 50 };    //123
            int[] My_Array3 = new int[] { 60, 70, 8, 9, 500 };    //647

            Person[] people =
            {
                new Person("Tom", "Microsoft"), new Person("Sam", "Google"),
                new Person("Bob", "JetBrains"), new Person("Mike", "Microsoft"),
            };
            Company[] companies =
            {
                new Company("Microsoft", "C#"),
                new Company("Google", "Go"),
                new Company("Oracle", "Java")
            };

            var employees = people.Join(companies, // второй набор
             p => p.Company, // свойство-селектор объекта из первого набора
             c => c.Title, // свойство-селектор объекта из второго набора
             (p, c) => new { Name = p.Name, Company = c.Title, Language = c.Language }); // результат

            foreach (var emp in employees)
                Console.WriteLine($"{emp.Name} - {emp.Company} ({emp.Language})");

            int Task_1 = My_Array1.First();
            int Task_2 = My_Array2.Last();
            int Task_3 = My_Array3.ElementAt(3);
            int Task_4 = My_Array1.Sum();
            double Task_5 = My_Array2.Average();

            Console.WriteLine($"Первое - {Task_1}; Второе - {Task_2}; Третье - {Task_3}; Четвертое - {Task_4}; Пятое - {Task_5};");
        }
    }

    public class Person
    {
        public string Name;
        public string Company;
        public Person(string Name, string Company)
        {
            this.Name = Name;
            this.Company = Company;
        }
    }
    public class Company
    {
        public string Title;
        public string Language;
        public Company(string Title, string Language)
        {
            this.Title = Title;
            this.Language = Language;                           
        }
    }
}