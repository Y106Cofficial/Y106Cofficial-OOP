﻿using System;

namespace lab_6
{

    class Osnova
    {
        static void Main(string[] args)
        {
            Predmet Table = new Predmet("Table", "Bedrok", 178954, "Green");
            Predmet Stool = new Predmet("Stool", "Vibranium", 584924, "Blue");        //Табуретка
            Predmet Chair = new Predmet("Chair", "Wood", 856193, "Yellow");
            Predmet Sofa = new Predmet("Sofa", "Leather", 675867, "Purple");
            Predmet Armchair = new Predmet("Armchair", "Wool", 453655, "Brown");

            NotBedrok Bedrok_Check = new NotBedrok();//выделение памяти под объект
            NotVibranium Vibranium_Check = new NotVibranium();
            CantFly Fly_Check = new CantFly();
            RealColor Color_Check = new RealColor();
        
           try
           {
                Bedrok_Check.Check_For_Bedrok(Table);    // 1 - исключение
                Vibranium_Check.Check_For_Vibranium(Stool);  // 2 - исключение  
                Chair.Change_My_Fly();
                Fly_Check.Check_For_Fly(Chair);  // 3 - исключнение
                //Sofa.serial_number = Sofa.serial_number / 0;   // 4 - исключение
                Color_Check.Check_For_Color(Armchair);   // 5 - исключение  
           }
            catch
           {
                Console.WriteLine("ERROR");
           }
             finally//позволяет продолжить выполнение программы после отлова исключения
           {
                 Console.WriteLine("Программа работает правильно!");
           }
            Debug.Assert(true == true);
        }
    }
}
