﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace lab_8
{
    public interface IFor_String    // интерфейс с методатми для изменения строки
    {
        void Udal_Znaki();
        void Add_Symbol();
        void Zamena_Na_Zaglavnye();
        void Zamena_Na_Propisnyje();

    }


    public class Game
    {
        public delegate void Attack();  //делегат для событий Attack
        public delegate void Heal();    //делегат для событий Heal
        public event Attack Attaka;    // событие Атака
        public event Heal Heall;   // событие Лечение
        public void On_Attack() => Attaka();    //вызов события Атака
        public void On_Heal() => Heall();   //вызов события Лечения
    }

    public class Game_Description   // класс в котором будут описыватся обратотчики событий
    {
        private int HP;
        /// <summary>
        /// HP не должно превышать 100 
        /// </summary>
        /// <param name="HP"></param>
        public Game_Description(int HP)
        {
            this.HP = HP;
        }

        public void Attack()
        {
            Console.WriteLine("В Атаку!!!!!!!");
        }

        public void Heal()  // методы реагирует по разному в зависимости от HP
        {
            Console.WriteLine();
            Console.WriteLine("<--->");
            if (HP < 50)
            {
                Console.WriteLine($"Ваш нынешний уровень здоровья = {HP}");
                Console.WriteLine("Провожу лечение 70%...90%...100%...Лечение закончено!");
                HP = 100;
                Console.WriteLine($"Ваш нынешний уровень здоровья = {HP}");
            }
            if (HP > 50 && HP < 90)
            {
                Console.WriteLine($"Ваш уровень здоровья довольно высок, вы не нуждаетесь в лечении!");
            }
            if (HP > 90)
            {
                Console.WriteLine("Вы здоровы. Идите в бой!");
            }
            Console.WriteLine("<--->");
            Console.WriteLine();
        }

        public void Show_HP()
        {
            Console.WriteLine($"Мое HP = {HP}");
        }
    }

    public class MyFun : IFor_String    // класс реализующтий методы
    {
        public string my_string = "Я, кушаю кашу, И МНЕ очень нравится.";

        public void Udal_Probely()
        {
            Console.WriteLine($"Исходная строка {my_string}");
            string new_string = Udal_Probely(my_string, Udal);
            string Udal_Probely(string str, Func<string,string> oper) => oper(str);
            string Udal(string str) => str.Replace(" ", "");
            Console.WriteLine($"Изменённая строка {new_string}");
        }

        public void Udal_Znaki()
        {
            Console.WriteLine($"Исходная строка: {my_string}");
            var new_string = Regex.Replace(my_string, "[-.?!)(,:]", string.Empty);
            my_string = new_string;
            Console.WriteLine($"Измененная строка: {my_string}");
        }

        public void Add_Symbol()
        {
            Console.WriteLine($"Исходная строка: {my_string}");
            my_string += " Я Добавленый";
            Console.WriteLine($"Измененная строка: {my_string}");
        }

        public void Zamena_Na_Zaglavnye()
        {
            Console.WriteLine($"Исходная строка: {my_string}");
            my_string = my_string.ToUpper();
            Console.WriteLine($"Измененная строка: {my_string}");
        }

        public void Zamena_Na_Propisnyje()
        {
            Console.WriteLine($"Исходная строка: {my_string}");
            my_string = my_string.ToLower();
            Console.WriteLine($"Измененная строка: {my_string}");
        }

        

        
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Game My_Game = new Game();      // создаем класс игра
            Game_Description Person_1 = new Game_Description(100);   // создаем трех персонажей с разными показателями HP
            Game_Description Person_2 = new Game_Description(30);
            Game_Description Person_3 = new Game_Description(70);

            My_Game.Attaka += Person_1.Attack;  // с помощью символа += мы подписываем метод Первого персонажа на событие Attaka нашей игры
            My_Game.Heall += Person_1.Heal; // подписываем метод Heal первого персонажа на событие Heall нашей игры
            My_Game.Attaka += Person_2.Attack;
            My_Game.Heall += Person_2.Heal;
            My_Game.Attaka += Person_3.Attack;
            My_Game.Heall += Person_3.Heal;

            My_Game.On_Attack();    // теперь основная инфа по событиям, когда мы вызываем событие атака, по факту мы вызываем все методы которые содержит это событие
            My_Game.On_Heal();  // событие атака в подписках имеет три метода Attack трех разных персонажей, поэтому когда мы ее вызовем на консоли будет прописано три раза одно и то же сообщение
                                // Так же и происходит с событием Heal, но там у нас работа с переменой HP, и для того чтобы показать что событие по разному реагирует, и выводятся следующие сообщения.
            Console.WriteLine($"Проверим наших бойцов.");
            Console.WriteLine($"У первого бойца HP было 100");
            Person_1.Show_HP();

            Console.WriteLine($"У второго бойца HP было 30");
            Person_2.Show_HP();

            Console.WriteLine($"У третьего бойца HP было 70");
            Person_3.Show_HP();

            Console.WriteLine("----------");

            MyFun My_String = new MyFun();
            My_String.Udal_Probely();
        }
    }
}

