﻿using System;
using System.Collections;
using System.Collections.Generic;
namespace Task
{
    public class Student<T> : IEnumerable<T>//класс студент
    {
        public string name;
        public int age;

        public Student(string name, int age)
        {
            this.name = name;
            this.age = age;
        }
        public List<T> mylist = new List<T>();

        public IEnumerator<T> GetEnumerator()
        {
            return mylist.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
    }
    public class Programm_Task_Main
    {
        static void Main()
        {
            Student<string> Misha = new Student<string>("Misha", 19);
            Student<string> Grisha = new Student<string>("Grisha", 21);
            Misha.mylist.Add("Girlfriend");
            Misha.mylist.Add("Dad");
            Misha.mylist.Add("Car");
            if (Misha.mylist.Contains("Girlfriend")) Console.WriteLine("Nu da");
            Misha.mylist.Remove("Car");
            if (!Misha.mylist.Contains("Car")) Console.WriteLine("Nu net");
            Console.WriteLine("2 zadanie==============================================================================");

            //=========================================================================================================


            Queue<string> My_Students = new Queue<string>();
            My_Students.Enqueue("Misha");
            My_Students.Enqueue("Grisha");
            My_Students.Enqueue("Maksim");
            My_Students.Enqueue("Egor");
            foreach (var item in My_Students)
            {
                Console.WriteLine(item);
            }
            int n = 2;
            for (int i = 0; i < n; i++)
            {
                My_Students.Dequeue();
            }
            Console.WriteLine("После удаления");
            foreach (var item in My_Students)
            {
                Console.WriteLine(item);
            }
            My_Students.Enqueue("Kiril");

            LinkedList<string> My_Students_2 = new LinkedList<string>();
            foreach (var item in My_Students)//заполнить студентов из 1 во 2ую
            {
                My_Students_2.AddFirst(item);
            }
            Console.WriteLine("Выводим вторую коллекцию: ");
            foreach (var item in My_Students_2)
            {
                Console.WriteLine(item);
            }
            foreach (var item in My_Students_2)
            {
                if (item == "Egor")
                {
                    Console.WriteLine("Вот он наш Егорка!");
                    break;
                }
            }

            ObservableCollection<Student<string>> My_Collection = new ObservableCollection<Student<string>>();
            My_Collection.CollectionChange += My_Collection.Say_Hello;
            My_Collection.On_CollectionChange();
            Student<string> Pashok = new Student<string>("Pashok", 19);
            Student<string> Ibragim = new Student<string>("Ibragim", 22);
            My_Collection.Add(Pashok);
            My_Collection.Add(Ibragim);
            Console.WriteLine("---");
            foreach (Student<string> item in My_Collection)
            {
                Console.WriteLine(item.name);
            }
            My_Collection.Remove(Pashok);
            Console.WriteLine("А после удаления!");
            foreach (Student<string> item in My_Collection)
            {
                Console.WriteLine(item.name);
            }
            Console.ReadLine();
        }
    }
}

    


