﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;

namespace Task
{
    public delegate void Second_Task_Delegate();
    //class Main_Vot
    //{

    //}

    public class ObservableCollection<T> where T : Student<string>
    {
        private T[] List_Example = new T[0];
        public event Second_Task_Delegate CollectionChange;

        public void On_CollectionChange() => CollectionChange();
        public void Say_Hello() => Console.WriteLine("Hello");

        public void Add(T value)
        {
            T[] new_List_Example = new T[List_Example.Length + 1];   // Увлеличили размер листа
            List_Example.CopyTo(new_List_Example, 0);    // переносим старые данные
            new_List_Example[new_List_Example.Length - 1] = value;  // заносим новое значение
            List_Example = new_List_Example;
        }
        public void RemoveAt(int value)
        {
            int index = value;
            if (index == -1) return;
            T[] new_List_Example = new T[List_Example.Length - 1];
            int offset = 0;
            for (int i = 0; i < List_Example.Length; i++)
            {
                if (i == index) { offset++; continue; }
                new_List_Example[i - offset] = List_Example[i];
            }
            List_Example = new_List_Example;
        }
        public bool Remove(T value1)
        {
            int temp;
            temp = IndexOf(value1);
            RemoveAt(temp);
            return true;
        }
        public int IndexOf(T item)
        {
            for (int i = 0; i < List_Example.Length; i++)
            {
                if (Equals(List_Example[i], item))
                {
                    return i;
                }
            }
            return -1;//экстренный выход
        }
        public IEnumerator<T> GetEnumerator()
        {
            return ((IEnumerable<T>)List_Example).GetEnumerator();
        }

    }
}