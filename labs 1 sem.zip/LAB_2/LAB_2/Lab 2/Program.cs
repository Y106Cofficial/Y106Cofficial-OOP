﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Lab_2
{
    internal class Program
    {
        static void Foo(ref double a)
        {
            Console.WriteLine("Введите нужный бал:\t\t");
            double bal = double.Parse(Console.ReadLine());
        }
        public partial class Abiturient
        {
            
            public readonly string field = "Дэиви 9";
            static int id;
            string FIO;
            public (string Ulitsa, int dom) Adres;
            public string Telephone;
            public double[] Otsenki = new double[4];
            public Abiturient(string fIO, (string Ulitsa, int dom) adres, string telephone, double[] otsenki)//конструктор с параметрами
            {   
                FIO = fIO;
                Adres = adres;
                Telephone = telephone;
                Otsenki = otsenki;
            }   
            public Abiturient()//Конструктор без параметров
            {

            }
            static  Abiturient()//Статический конструктор
            {
                id = 10;
            }
            public string fio//свойства гет и сет
            {
                get
                {
                    return FIO;
                }
                set
                {
                    FIO = value;
                    
                }
            }

        }

        public partial class Abiturient
        {

             public void Sredbal()//метод средний бал
            {
                int Sredniy_bal = 0;
                foreach (int i in Otsenki)
                {
                    Sredniy_bal+=i;
                }
                Console.WriteLine("Средний бал:\t\t" + Sredniy_bal/4);
            }
            public void Minimalnay_otsenka()//метод вычисления минимальной оценки 
            {
                double min_otsenka = Otsenki.Min();
                Console.WriteLine("Наименьшая оценка:\t" + min_otsenka);
            }

            public void Maximalnaya_otsenka()//метод вычисления максимальной оценки 
            {
                double max_otsenka = Otsenki.Max();
                Console.WriteLine("Наибольшая оценка:\t" + max_otsenka);
            }
            public void Summa_Ballov()
            {
                double sm_bal = Otsenki.Sum();
                Console.WriteLine("Сумма балллов:\t" + sm_bal);
                return;
            }
        }
        

        static void Main(string[] args)
        {
            Abiturient[] Spisok = new Abiturient[5];//массив экзэмпляров класса
            Spisok[0] = new Abiturient();
            Spisok[1] = new Abiturient();
            Spisok[2] = new Abiturient();
            Spisok[3] = new Abiturient();
            Spisok[4] = new Abiturient("Адамович Евгений Павлович", ("ул.Партизанская д.", 666), "+375-29-333-33-33", new double[4] { 10, 3, 9, 9 });

          
            


            Spisok[0].fio = "Bondar Ales Dmitrievich";
            Spisok[0].Adres.Ulitsa = "ул.Партизанская д.";
            Spisok[0].Adres.dom = 666;
            Spisok[0].Otsenki = new double[4] { 7, 2, 1, 4 };
            Spisok[0].Telephone = "+375-29-333-33-33";
            Spisok[0].Sredbal();
            Spisok[0].Maximalnaya_otsenka();
            Spisok[0].Minimalnay_otsenka();
            Spisok[0].Summa_Ballov();
            Console.WriteLine();

            Spisok[1].fio = "Адамович Евгений Павлович";
            Spisok[1].Adres.Ulitsa = "ул.Неизвестно д.";
            Spisok[1].Adres.dom = 999;
            Spisok[1].Otsenki = new double[4] { 10, 3, 9, 9 };
            Spisok[1].Telephone = "+375-29-444-44-44";
            Spisok[1].Sredbal();
            Spisok[1].Maximalnaya_otsenka();
            Spisok[1].Minimalnay_otsenka();
            Spisok[1].Summa_Ballov();
            Console.WriteLine();

            Spisok[2].fio = "Курилович Артемий Незнаю";
            Spisok[2].Adres.Ulitsa = "ул.Неизвестно д.";
            Spisok[2].Adres.dom = 666;
            Spisok[2].Otsenki = new double[4] { 7, 6, 5, 7 };
            Spisok[2].Telephone = "+375-29-555-55-55";
            Spisok[2].Sredbal();
            Spisok[2].Maximalnaya_otsenka();
            Spisok[2].Minimalnay_otsenka();
            Spisok[2].Summa_Ballov();
            Console.WriteLine();

            Spisok[3].fio = "Какой-то Шкет Понятия не имею ";
            Spisok[3].Adres.Ulitsa = "ул.Неизвестно д.";
            Spisok[3].Adres.dom = 999;
            Spisok[3].Otsenki = new double[4] { 10, 3, 9, 9 };
            Spisok[3].Telephone = "+375-29-666-66-66";
            Spisok[3].Sredbal();
            Spisok[3].Maximalnaya_otsenka();
            Spisok[3].Minimalnay_otsenka();
            Spisok[3].Summa_Ballov();
            Console.WriteLine();

            double bal = 0;
            Foo(ref bal);

        }
    }
}
