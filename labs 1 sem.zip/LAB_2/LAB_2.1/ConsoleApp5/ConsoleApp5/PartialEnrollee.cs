﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp5
{
    partial class Enrollee
    {
        public double getMinScore()
        {
            double result = estimates[0];

            for (int i = 1; i < estimates.Length; i++)
            {
                if (result > estimates[i])
                {
                    result = estimates[i];
                }
            }

            return result;
        }
    }
}
