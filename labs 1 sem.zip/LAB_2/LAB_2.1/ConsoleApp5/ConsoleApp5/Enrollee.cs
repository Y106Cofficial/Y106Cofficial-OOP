﻿using System;

namespace ConsoleApp5
{
    partial class Enrollee
    {
        public static int amountExemplar;
        private bool isInitialized;
        private string fio;
        private (string street, string numberHome) address;
        private string phone;
        private double[] estimates = new double[4];
        static Enrollee()
        {
            amountExemplar = amountExemplar++;
        }
        public Enrollee()
        {
            IsInitialized = true;
        }
        public Enrollee(int inputId, string inputFIO, string inputStreet, string numberHome, string inputPhone, double[] inputEstimates) {
            this.Id = inputId.GetHashCode();
            this.FIO = inputFIO;
            this.Address = (inputStreet, numberHome);
            this.Phone = inputPhone;
            this.Estimates = inputEstimates;
        }

        public bool IsInitialized
        {
            get => isInitialized;
            set => isInitialized = value;
        }

        public int Id { get; }
        public string FIO
        {
            get => fio;
            set
            {
                if (char.IsLower(value[0]))
                    fio = char.ToUpper(value[0]) + value.Remove(0, 1);
                else
                {
                    fio = value;
                }
            }
        }

        public (string, string) Address
        {
            get => address;
            set {
                if (value.Item1.Substring(0,3) != "ул.")
                {
                    throw new Exception("Адресс должен начинать с `ул.`");
                }
                else
                {
                    address = value;
                }
            }
        }

        public string Phone
        {
            get => phone;
            set {
                if(value.Length > 13)
                {
                    throw new Exception("Длина номера привышает допустимую длину");
                }
                phone = value;
            }
        }
        public double[] Estimates
        {
            get => estimates;
            set
            {
                for (int i = 0; i < value.Length; i++)
                {
                    if (value[i] <= 0 && value[i] > 10)
                    {
                        throw new Exception("Неверная оценка");
                    }
                }

                estimates = value;
            }
        }

        static public DateTime getTime()
        {
            return DateTime.Now;
        }

        public double getAverageScore()
        {
            double result = 0;

            for (int i = 0; i < estimates.Length; i++)
            {
                result += estimates[i];
            }

            return result / (estimates.Length);
        }

        public double getMaxScore()
        {
            double result = 0;

            for (int i = 0; i < estimates.Length; i++)
            {
                if(result< estimates[i])
                {
                    result = estimates[i];
                }
            }

            return result;
        }

        public bool getSumScore(double sum)
        {
            double result = 0;

            for (int i = 0; i < estimates.Length; i++)
            {
                result += estimates[i];
            }

            return result > sum;
        }
    }
}
