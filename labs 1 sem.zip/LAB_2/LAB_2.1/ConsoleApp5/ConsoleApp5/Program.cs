﻿using ConsoleApp5;
using System;
 
namespace EnrolleeClass
{
    internal class Program
    {  
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Введите кол-во абитуриентов: ");
                double count = Convert.ToDouble(Console.ReadLine());
                Enrollee[] enrollees = new Enrollee[Convert.ToInt32(count)];

                for (int i = 0; i < count; i++)
                {
                    Console.WriteLine("Введите ФИО: ");
                    string FIO = Console.ReadLine();
                    Console.WriteLine("Введите улицу начиная с `ул.`: ");
                    string street = Console.ReadLine();
                    Console.WriteLine("Введите номер дома: ");
                    string numberHome = Console.ReadLine();
                    Console.WriteLine("Введите телефон: ");
                    string phone = Console.ReadLine();
                    double[] estimates = new double[4];
                    for (int j = 0; j < estimates.Length; j++)
                    {
                        Console.WriteLine("Введите оценку {0}", j + 1);
                        estimates[j] = Convert.ToDouble(Console.ReadLine());
                    }
                    enrollees[i] = new Enrollee(i, FIO, street, numberHome, phone, estimates);
                }

                Console.WriteLine("=====================================================================================================");
                Console.WriteLine("Абитуриенты");
                for (int i = 0; i < count; i++)
                {
                    Console.WriteLine("=====================================================================================================");
                    Console.WriteLine("ФИО: {0}, Адрес: {1}, {2}, Телефон: {3}, Оценки абитуриента: {4}", enrollees[i].FIO, enrollees[i].Address.Item1, enrollees[i].Address.Item2, enrollees[i].Phone, String.Join(", ", enrollees[i].Estimates));
                    Console.WriteLine("Средний балл абитуриента: {0}", enrollees[i].getAverageScore());
                    Console.WriteLine("Самая высокая оценка абитуриента: {0}", enrollees[i].getMaxScore());
                    Console.WriteLine("Самая низкая оценка абитуриента: {0}", enrollees[i].getMinScore());
                }
                Console.WriteLine("\n");
                Console.WriteLine("=====================================================================================================");
                Console.WriteLine("Список абитуриентов с неудовлетворительными оценками: ");
                for (int i = 0; i < count; i++)
                {
                   if(enrollees[i].getMinScore() < 4)
                    {
                        Console.WriteLine("ФИО: {0}, Адрес: {1}, {2}, Телефон: {3}, Оценки абитуриента: {4}", enrollees[i].FIO, enrollees[i].Address.Item1, enrollees[i].Address.Item2, enrollees[i].Phone, String.Join(", ", enrollees[i].Estimates));
                    }
                }
                Console.WriteLine("\n");
                Console.WriteLine("=====================================================================================================");
                Console.WriteLine("Введите удовлетворительную сумму баллов: ");
                double sum = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Cписок абитуриентов, у которых сумма баллов выше заданной: ");
                for (int i = 0; i < count; i++)
                {
                    if(enrollees[i].getSumScore(sum))
                    {
                        Console.WriteLine("ФИО: {0}, Адрес: {1}, {2}, Телефон: {3}, Оценки абитуриента: {4}", enrollees[i].FIO, enrollees[i].Address.Item1, enrollees[i].Address.Item2, enrollees[i].Phone, String.Join(", ", enrollees[i].Estimates));
                    }
                }
                Console.WriteLine("\n");
                Console.WriteLine("=====================================================================================================");
                Console.WriteLine("Создание анонимного типа....");
                var enrolleesAnonymous = new { FIO = "Вася Пупкин", Address = ("ул. Притыцкого", 12), Phone = "+375297061497", Estimates = new double[] { 9, 4, 5, 6} };
                Console.WriteLine("Вывод анонимного типа....");
                Console.WriteLine("ФИО: {0}, Адрес: {1}, {2}, Телефон: {3}, Оценки абитуриента: {4}", enrolleesAnonymous.FIO, enrolleesAnonymous.Address.Item1, enrolleesAnonymous.Address.Item2, enrolleesAnonymous.Phone, String.Join(", ", enrolleesAnonymous.Estimates));
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
        } 
    } 
}