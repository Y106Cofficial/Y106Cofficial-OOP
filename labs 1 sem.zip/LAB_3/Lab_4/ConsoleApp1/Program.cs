﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;

namespace Lab_4
{

    public partial class Set<T> : IEnumerable<T>
    {
        private List<T> _items = new List<T>();//коллекция хранимых данных 
        public int Count => _items.Count;//количество элементов 


        //добовление элемента 
        public void Add(T item)
        {
            //проверка входных данных на пустоту 
            if (item == null)
            {
                throw new ArgumentNullException(nameof(item));
            }
            //короче по сути множество содержат уникальные элементы, поэтому если множество уже содержит эту херь, то не добовлять её
            if (!_items.Contains(item))
            {
                _items.Add(item);
            }
        }
        //удаление элемента
        public void RemoveOperation(T item)//удаление элемента 
        {
            if (item == null)//проверка на пустоту 
            {
                throw new ArgumentNullException(nameof(item));
            }
            //Если множество не содержит данный элемент то мы не можем его удалить  
            if (!_items.Contains(item))
            {
                throw new KeyNotFoundException($"Элемент {item} не найдем в множестве.");
            }
            _items.Remove(item);
        }

        //обьединение множеств
        public static Set<T> Union(Set<T> set1, Set<T> set2)
        {
            if (set1 == null)//проверка входных данных на пустоту 
            {
                throw new ArgumentNullException(nameof(set1));
            }
            if (set2 == null)//проверка входных данных на пустоту 
            {
                throw new ArgumentNullException(nameof(set2));
            }

            var resultSet = new Set<T>();//результитрующее множество
            var items = new List<T>();// элементы ркзультирующего множества 

            if (set1._items != null && set1._items.Count > 0)//если первое входящее множество содержит элементы данных, то добовляем его в результирующее множенство
            {
                items.AddRange(new List<T>(set1._items)); //крч, список это ссылочный тип надо не просто передавать данные а создавать дубликаты
            }
            if (set2._items != null && set2._items.Count > 0)
            {
                items.AddRange(new List<T>(set2._items));
            }
            resultSet._items = items.Distinct().ToList();//удалить все дубликаты из реультирующего множества данных
            return resultSet;//возврат результирующего множества  
        }

        //пересечение множеств
        public static Set<T> Intersection(Set<T> set1, Set<T> set2)
        {
            if (set1 == null)//проверка входных данных на пустоту 
            {
                throw new ArgumentNullException(nameof(set1));
            }
            if (set2 == null)//проверка входных данных на пустоту 
            {
                throw new ArgumentNullException(nameof(set2));
            }
            var resultSet = new Set<T>();//результирующее множество

            if (set1.Count < set2.Count)//выбираем множество содержащее меньшее наименьшее количество элементов 
            {
                //первое множество меньше, проверяем все элементы выбранного множества
                foreach (var item in set1._items)
                {
                    //если элемент из 1ого множества содержится во втором то добовляем его в результирующее множество 
                    if (set2._items.Contains(item))
                    {
                        resultSet.Add(item);
                    }
                }
            }
            else
            {
                //Второе множество меньше или они равны, проверяем все элементы выбранного множества
                foreach (var item in set2._items)
                {
                    //если элемнет из второго множества есть в первом , то добавить его в результирующее множество
                    if (set1._items.Contains(item))
                    {
                        resultSet.Add(item);
                    }
                }
            }
            return resultSet;//возвращаем результирующее множество

        }
        //разности множеств 
        public static Set<T> Difference(Set<T> set1, Set<T> set2)
        {
            if (set1 == null)//проверка входных данных на пустоту 
            {
                throw new ArgumentNullException(nameof(set1));
            }
            if (set2 == null)//проверка входных данных на пустоту 
            {
                throw new ArgumentNullException(nameof(set2));
            }
            var resultSet = new Set<T>();//результирующее множество

            //Переборка всех элементов 1ого множества 
            foreach (var item in set1._items)
            {
                //если элемент из 1ого не содержится во 2ом то добавить его в результирующее множество 
                if (!set2._items.Contains(item))
                {
                    resultSet.Add(item);
                }
            }

            //переборка всех элементов 2ого множества
            foreach (var item in set2._items)
            {
                //если элемент из 2ого не содержится во 1ом то добавить его в результирующее множество
                if (!set1._items.Contains(item))
                {
                    resultSet.Add(item);
                }
            }
            resultSet._items = resultSet._items.Distinct().ToList();//удаление всех дубликатов из результ. множества 
            return resultSet;//возврат значения 
        }
        public static bool SubSet(Set<T> set1, Set<T> set2)
        {
            if (set1 == null)//проверка входных данных на пустоту 
            {
                throw new ArgumentNullException(nameof(set1));
            }
            if (set2 == null)//проверка входных данных на пустоту 
            {
                throw new ArgumentNullException(nameof(set2));
            }
            //Переборка элементов первого множества, если все элементы первого множества содержатся во втором
            //то это подиножества. Возращает True  иначе False
            var result = set1._items.All(s => set2._items.Contains(s));
            return result;
        }
        public static void Shortest_word(Set<string> set)//Поиск самого короткого слова
        {
            
        }
        public IEnumerator<T> GetEnumerator()//перечислитель для итерации по коллекции
        {
            return _items.GetEnumerator(); // перечислитель списка элементов данных множеств 
        }

        IEnumerator IEnumerable.GetEnumerator()//объект который используется для прохода по коллекции
        {
            return _items.GetEnumerator();//использование перечислителя списка этих множеств 
        }
    }
    public partial class Set<T>
    {
        private class Developer
        {
            private int Id = 5;
            private string FIO = "Sevastyanovich Yuriy";
            private string Otdel = "FIT";
        }
    }
    internal class Program
    {
       
        public static void Shortest_Vord(string[] Array)
        {
            Console.Write("Введите размер массива:\t");
            string[] MyArray = new string[int.Parse(Console.ReadLine())];
            for (int i = 0; i < MyArray.Length; i++)
            {
                Console.Write($"Введите {i} элемент массива:\t");
                MyArray[i]=Console.ReadLine();
            }
            int shortvord = MyArray[0].Length;
            int indexmin = 0;
            for (int i = 0; i < MyArray.Length; i++)
            {
                if (MyArray[i].Length < shortvord)
                {
                    shortvord = MyArray[i].Length;
                    indexmin = i;
                }
            }
            Console.WriteLine("Краичайшее слово:\t" + MyArray[indexmin]);

        }
        private static void Print(Set<int> set, string nameSet)//вывод множества на консоль 
        {
            Console.Write(nameSet);
            foreach (var item in set)
            {
                Console.Write($"{item} ");
            }
            Console.WriteLine();
        }
        static void Main(string[] args)
        {
            var set1 = new Set<int>()
            {
                1,2,3,4,5,6,7,8,9,0,10,11,12
            };
            var set2 = new Set<int>()
            {
                4,5,6,7,8,9,2,3,5,4
            };
            var set3 = new Set<int>()
            {
                2,3,4
            };

            var union = Set<int>.Union(set1, set2);
            var difference = Set<int>.Difference(set1, set2);
            var intersection = Set<int>.Intersection(set1, set2);
            var subset1 = Set<int>.SubSet(set3,set1);
            var subset2 = Set<int>.SubSet(set3,set2);

            Print(set1, "Первое множество: ");
            Print(set2, "Второе множество: ");
            Print(set3, "Третье множество: ");

            Print(union, "Объединение первого и второго множеств: ");
            Print(difference, "Разность первого и второго множеств: ");
            Print(intersection, "Пересечение первого и второго множеств: ");

            if (subset1)
            {
                Console.WriteLine("Третье множество является подмножеством первого");
            }
            else
            {
                Console.WriteLine("Третье множество не является подмножеством первого");
            }
            if (subset2)
            {
                Console.WriteLine("Третье множество является подмножеством второго");
            }
            else
            {
                Console.WriteLine("Третье множество не является подмножеством второго ");
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();

            //кратчайшее слово
            string[] slova = new string[5];
            Shortest_Vord(slova);
                

        }
    }
}
