﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3Ales
{
    public partial class FixedStack<T>
    {
        private int id = 14;
        private T[] items; // элементы стека
        private int count;  // количество элементов
        const int n = 10;   // количество элементов в массиве по умолчанию
        public FixedStack()
        {
            items = new T[n];
        }
        public FixedStack(int length)
        {
            items = new T[length];
        }
        // пуст ли стек
        public bool IsEmpty
        {
            get { return count == 0; }
        }
        // размер стека
        public int Count
        {
            get { return count; }
        }
        // добвление элемента5
    }


    public partial class FixedStack<T>
    {
        public void Push(T item)
        {
            // если стек заполнен, выбрасываем исключение
            if (count == items.Length)
                throw new InvalidOperationException("Переполнение стека");
            items[count++] = item;
        }
        // извлечение элемента
        public T Pop()
        {
            // если стек пуст, выбрасываем исключение
            if (IsEmpty)
                throw new InvalidOperationException("Стек пуст");
            T item = items[--count];
            items[count] = default(T); // сбрасываем ссылку
            return item;
        }
        // возвращаем элемент из верхушки стека
        public T Peek()
        {
            // если стек пуст, выбрасываем исключение
            if (IsEmpty)
                throw new InvalidOperationException("Стек пуст");
            return items[count - 1];
        }
        public void Zapolnenye(int[] a)
        {
            Random random = new Random();
            Console.WriteLine("Введиите длину массива:\t");
            int Length_m = int.Parse(Console.ReadLine());
            int[] MyArray = new int[Length_m];
            for (int i = 0; i < MyArray.Length; i++)
            {
                MyArray[i] = random.Next(-50,50);   
            }
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] Myarray;
            

        }
    }
}
