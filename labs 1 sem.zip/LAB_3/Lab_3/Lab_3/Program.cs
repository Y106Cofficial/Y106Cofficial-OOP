﻿using System;
using System.CodeDom;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;

namespace Lab_4
{
        
    public partial class Set<T> : IEnumerable<T>
    {
        private List<T> _items = new List<T>();//коллекция хранимых данных 
        public int Count => _items.Count;//количество элементов 


        //добовление элемента 
        public void Add(T item)
        {
            //проверка входных данных на пустоту 
            if (item == null)
            {
                throw new ArgumentNullException(nameof(item));
            }
            //короче по сути множество содержат уникальные элементы, поэтому если множество уже содержит эту херь, то не добовлять её
            if (!_items.Contains(item))
            {
                _items.Add(item);
            }
        }
        //удаление элемента
        public void Remove(T item)//удаление элемента 
        {
            if (item == null)//проверка на пустоту 
            {
                throw new ArgumentNullException(nameof(item));
            }
            //Если множество не содержит данный элемент то мы не можем его удалить  
            if (!_items.Contains(item))
            {
                throw new KeyNotFoundException($"Элемент {item} не найдем в множестве.");
            }
            _items.Remove(item);
        }

        //обьединение множеств
        public static Set<T> Union(Set<T> set1, Set<T> set2)
        {
            if (set1 == null)//проверка входных данных на пустоту 
            {
                throw new ArgumentNullException(nameof(set1));
            }
            if (set2 == null)//проверка входных данных на пустоту 
            {
                throw new ArgumentNullException(nameof(set2));
            }

            var resultSet = new Set<T>();//результитрующее множество
            var items = new List<T>();// элементы ркзультирующего множества 

            if (set1._items != null && set1._items.Count > 0)//если первое входящее множество содержит элементы данных, то добовляем его в результирующее множенство
            {
                items.AddRange(new List<T>(set1._items)); //крч, список это ссылочный тип надо не просто передавать данные а создавать дубликаты
            }
            if (set2._items != null && set2._items.Count > 0)
            {
                items.AddRange(new List<T>(set2._items));
            }
            resultSet._items = items.Distinct().ToList();//удалить все дубликаты из реультирующего множества данных
            return resultSet;//возврат результирующего множества  
        }
        public static Set<T> Union(Set<T> set3, Set<T> set4, Set<T> set5)//перегрузка метода Union
        {
            if (set3 == null)//проверка входных данных на пустоту 
            {
                throw new ArgumentNullException(nameof(set3));
            }
            if (set4 == null)//проверка входных данных на пустоту 
            {
                throw new ArgumentNullException(nameof(set4));
            }
            if (set5 == null)//проверка входных данных на пустоту 
            {
                throw new ArgumentNullException(nameof(set5));
            }

            var resultSet = new Set<T>();//результитрующее множество
            var items = new List<T>();// элементы ркзультирующего множества 

            if (set3._items != null && set3._items.Count > 0)//если первое входящее множество содержит элементы данных, то добовляем его в результирующее множенство
            {
                items.AddRange(new List<T>(set3._items)); //крч, список это ссылочный тип надо не просто передавать данные а создавать дубликаты
            }
            if (set4._items != null && set4._items.Count > 0)
            {
                items.AddRange(new List<T>(set4._items));
            }
            if (set5._items != null && set5._items.Count > 0)
            {
                items.AddRange(new List<T>(set5._items));
            }
            resultSet._items = items.Distinct().ToList();//удалить все дубликаты из реультирующего множества данных
            return resultSet;//возврат результирующего множества  
        }


        //пересечение множеств
        public static Set<T> Intersection(Set<T> set1, Set<T> set2)
        {
            if (set1 == null)//проверка входных данных на пустоту 
            {
                throw new ArgumentNullException(nameof(set1));
            }
            if (set2 == null)//проверка входных данных на пустоту 
            {
                throw new ArgumentNullException(nameof(set2));
            }
            var resultSet = new Set<T>();//результирующее множество

            if (set1.Count < set2.Count)//выбираем множество содержащее меньшее наименьшее количество элементов 
            {
                //первое множество меньше, проверяем все элементы выбранного множества
                foreach (var item in set1._items)
                {
                    //если элемент из 1ого множества содержится во втором то добовляем его в результирующее множество 
                    if (set2._items.Contains(item))
                    {
                        resultSet.Add(item);
                    }
                }
            }
            else
            {
                //Второе множество меньше или они равны, проверяем все элементы выбранного множества
                foreach (var item in set2._items)
                {
                    //если элемнет из второго множества есть в первом , то добавить его в результирующее множество
                    if (set1._items.Contains(item))
                    {
                        resultSet.Add(item);
                    }
                }
            }
            return resultSet;//возвращаем результирующее множество

        }
        //разности множеств 
        public static Set<T> Difference(Set<T> set1, Set<T> set2)
        {
            if (set1 == null)//проверка входных данных на пустоту 
            {
                throw new ArgumentNullException(nameof(set1));
            }
            if (set2 == null)//проверка входных данных на пустоту 
            {
                throw new ArgumentNullException(nameof(set2));
            }
            var resultSet = new Set<T>();//результирующее множество

            //Переборка всех элементов 1ого множества 
            foreach (var item in set1._items)
            {
                //если элемент из 1ого не содержится во 2ом то добавить его в результирующее множество 
                if (!set2._items.Contains(item))
                {
                    resultSet.Add(item);
                }
            }

            //переборка всех элементов 2ого множества
            foreach (var item in set2._items)
            {
                //если элемент из 2ого не содержится во 1ом то добавить его в результирующее множество
                if (!set1._items.Contains(item))
                {
                    resultSet.Add(item);
                }
            }
            resultSet._items = resultSet._items.Distinct().ToList();//удаление всех дубликатов из результ. множества 
            return resultSet;//возврат значения 
        }


        public static Set<T> Difference(Set<T> set1, Set<T> set2, Set<T> set3)//перегрузка метода Difference
        {
            if (set1 == null)//проверка входных данных на пустоту 
            {
                throw new ArgumentNullException(nameof(set1));
            }
            if (set2 == null)//проверка входных данных на пустоту 
            {
                throw new ArgumentNullException(nameof(set2));
            }
            if (set3 == null)//проверка входных данных на пустоту 
            {
                throw new ArgumentNullException(nameof(set3));
            }
            var resultSet = new Set<T>();//результирующее множество

            //Переборка всех элементов 1ого множества 
            foreach (var item in set1._items)
            {
                //если элемент из 1ого не содержится во 2ом то добавить его в результирующее множество 
                if (!set2._items.Contains(item))
                {
                    resultSet.Add(item);
                }
            }
            //Переборка всех элементов 1ого множества 
            foreach (var item in set1._items)
            {
                //если элемент из 1ого не содержится во 3ом то добавить его в результирующее множество 
                if (!set3._items.Contains(item))
                {
                    resultSet.Add(item);
                }
            }

            //переборка всех элементов 2ого множества
            foreach (var item in set2._items)
            {
                //если элемент из 2ого не содержится во 1ом то добавить его в результирующее множество
                if (!set1._items.Contains(item))
                {
                    resultSet.Add(item);
                }
            }
            //переборка всех элементов 2ого множества
            foreach (var item in set2._items)
            {
                //если элемент из 2ого не содержится во 3ом то добавить его в результирующее множество
                if (!set3._items.Contains(item))
                {
                    resultSet.Add(item);
                }
            }
            //переборка всех элементов 3его множества
            foreach (var item in set3._items)
            {
                //если элемент из 3ого не содержится во 2ом то добавить его в результирующее множество
                if (!set2._items.Contains(item))
                {
                    resultSet.Add(item);
                }
            }
            //переборка всех элементов 3его множества
            foreach (var item in set3._items)
            {
                //если элемент из 3ого не содержится во 1ом то добавить его в результирующее множество
                if (!set1._items.Contains(item))
                {
                    resultSet.Add(item);
                }
            }
            resultSet._items = resultSet._items.Distinct().ToList();//удаление всех дубликатов из результ. множества 
            return resultSet;//возврат значения 
        }



        public static bool SubSet(Set<T> set1, Set<T> set2)
        {
            if (set1 == null)//проверка входных данных на пустоту 
            {
                throw new ArgumentNullException(nameof(set1));
            }
            if (set2 == null)//проверка входных данных на пустоту 
            {
                throw new ArgumentNullException(nameof(set2));
            }
            //Переборка элементов первого множества, если все элементы первого множества содержатся во втором
            //то это подиножества. Возращает True  иначе False
            var result = set1._items.All(s => set2._items.Contains(s));
            return result;
        }
        public static void Shortest_word(Set<string> set)//Поиск самого короткого слова
        {

        }
        public IEnumerator<T> GetEnumerator()//перечислитель для итерации по коллекции
        {
            return _items.GetEnumerator(); // перечислитель списка элементов данных множеств 
        }

        IEnumerator IEnumerable.GetEnumerator()//объект который используется для прохода по коллекции
        {
            return _items.GetEnumerator();//использование перечислителя списка этих множеств 
        }
    }
    public partial class Set<T>
    {
        private class Developer
        {
            private int Id = 5;
            private string FIO = "Sevastyanovich Yuriy";
            private string Otdel = "FIT";
        }
      
       
    }
    internal class Program
    {

        public static void Shortest_Vord(string[] Array)
        {
            Console.Write("Введите размер массива:\t");
            string[] MyArray = new string[int.Parse(Console.ReadLine())];
            for (int i = 0; i < MyArray.Length; i++)
            {
                Console.Write($"Введите {i} элемент массива:\t");
                MyArray[i] = Console.ReadLine();
            }
            int shortvord = MyArray[0].Length;
            int indexmin = 0;
            for (int i = 0; i < MyArray.Length; i++)
            {
                if (MyArray[i].Length < shortvord)
                {
                    shortvord = MyArray[i].Length;
                    indexmin = i;
                }
            }
            Console.WriteLine("Краичайшее слово:\t" + MyArray[indexmin]);

        }
        private static void Print(Set<int> set, string nameSet)//вывод множества на консоль 
        {
            Console.Write(nameSet);
            foreach (var item in set)
            {
                Console.Write($"{item} ");
            }
            Console.WriteLine();
        }
        static void Main(string[] args)
        {
            var set1 = new Set<int>()
            {
                11,12,34,2,3,5,7
            };
            var set2 = new Set<int>()
            {
                4,5,6,7,8,9,2,3,5,4
            };
            var set3 = new Set<int>()
            {
                2,3,4
            };

            HashSet<int> set4 = new HashSet<int>() { 14,15,16,17 };
            List<int> values = new List<int>() { 22, 23, 24, 27 };
            set1.Union(set4);
            set2.Union(values);
            Print(set1, "Первое множество: ");
            Print(set2, "Второе множество: ");
            Print(set3, "Третье множество: ");
            Console.WriteLine("================================================================================================");
            //Использование добавления Add в первое множество, в остальные мне было впадлу писать 
            Console.Write("Сколько раз хотите выполнить операцию добавления в множество 1:\t");
            int Counter_Add = int.Parse(Console.ReadLine());
            for (int i = 0; i < Counter_Add; i++)
            {
                Console.WriteLine("Введите число которое хотите добаввит в 1ое множество:\t");
                int Add_number = int.Parse(Console.ReadLine());
                set1.Add(Add_number);
            }
            Print(set1, "Первое множество: ");
            Console.WriteLine("================================================================================================");
            //операция удаления Remove в первом множестве, мне дляостальных тоже впадлу,
            // по идее можешь Эдом и Ремувом изначально множества заполнить с клавиатуры, но я не буду мне лень, если что напиши мне в тг
            //у тебя же в пятницу или в субюботу лаба что не поймёшь могу на неделе глянуть
            Console.WriteLine("Сколько раз хотите выполнить операцию уаления в множестве 1:\t");
            int Counter_Remove = int.Parse(Console.ReadLine());
            for (int i = 0; i < Counter_Remove; i++)
            {
                Console.WriteLine("Введите число которое хотите удалить из множества 1");
                int Remove_number = int.Parse(Console.ReadLine());
                set1.Remove(Remove_number);
            }
            Print(set1, "Первое множество: ");
            Console.WriteLine("================================================================================================");

            var union = Set<int>.Union(set1, set2);
            var difference = Set<int>.Difference(set1, set2, set3);
            var intersection = Set<int>.Intersection(set1, set2);
            var subset1 = Set<int>.SubSet(set3, set1);
            var subset2 = Set<int>.SubSet(set3, set2);
           

            Print(set1, "Первое множество: ");
            Print(set2, "Второе множество: ");
            Print(set3, "Третье множество: ");
            Console.WriteLine("================================================================================================");
            Print(union, "Объединение первого и второго множеств: ");
            Print(difference, "Разность первого и второго и третьего множеств: ");
            Print(intersection, "Пересечение первого и второго множеств: ");

            if (subset1)
            {
                Console.WriteLine("Третье множество является подмножеством первого");
            }
            else
            {
                Console.WriteLine("Третье множество не является подмножеством первого");
            }
            if (subset2)
            {
                Console.WriteLine("Третье множество является подмножеством второго");
            }
            else
            {
                Console.WriteLine("Третье множество не является подмножеством второго ");
            }
            Console.WriteLine("================================================================================================");
            SortedSet<int> result_set1 = new SortedSet<int>(set1);
            Console.WriteLine("Сортиорвка первого множества:\t");
            foreach (var val in result_set1)
            {
                Console.Write(val + ",");
            }
            Console.WriteLine();
            Console.WriteLine("================================================================================================");

            SortedSet<int> result_set2 = new SortedSet<int>(set2);
            Console.WriteLine("Сортиорвка второго множества:\t");
            foreach (var val in result_set2)
            {
                Console.Write( val + ",");
            }
            Console.WriteLine();
            Console.WriteLine("================================================================================================");

            SortedSet<int> result_set3 = new SortedSet<int>(set3);
            Console.WriteLine("Сортиорвка третьего множества:\t");
            foreach (var val in result_set3)
            {
                Console.Write(val + ",");
            }
            Console.WriteLine();
            Console.WriteLine("================================================================================================");

            //кратчайшее слово
            string[] slova = new string[5];
            Shortest_Vord(slova);

            Console.WriteLine("КАКАЯ ДОСАДА ЧТО Я НЕ ГЕНИЙ ПРОГРАММИРОВАНИЯ И НЕ КРУГЛЫЙ ОТЛИЧНИК");
        }
    }
}

